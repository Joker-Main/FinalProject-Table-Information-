package com.example.week8

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class Main2Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val txtShow = findViewById<TextView>(R.id.txtShow)
        val txtShow2 = findViewById<TextView>(R.id.txtShow2)

        var strShow: String = intent.getStringExtra("SendStuff")
        txtShow.text = strShow
        var strShow2: String = intent.getStringExtra("SendStuff2")
        txtShow2.text = strShow2

    }
}
